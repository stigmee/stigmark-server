const requestUrl = 'https://philippe-anel.fr/'

function stigmark(url) {
    console.log(`stigmark: ${url}`);

    /*
    const request = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url }),
    };
    fetch(requestUrl, request)
        .then(response => response.json())
        .then(response => { console.log('response: %o', response); })
        .catch(error => console.log('Error:', error));
    */

    const o = {};
    o[url] = true;
    chrome.storage.sync.set(o);
}

function stigunmark(url) {
    console.log(`stigunmark: ${url}`);

    /*
    const request = {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url }),
    };
    fetch(requestUrl, request)
        .then(response => response.json())
        .then(response => { console.log('response: %o', response); })
        .catch(error => console.log('Error:', error));
    */
   
    chrome.storage.sync.remove(url);
}

async function is_stigmarked(url) {
    return await chrome.storage.sync.get(url);
}

function setBadgeColor(color) {
    chrome.action.setBadgeBackgroundColor(
        { color: color },
        () => { },
    );
}

function setBadgetText(text) {
    chrome.action.setBadgeText({
        text: text,
    });
}

async function getCurrentTab() {
    let queryOptions = { active: true, currentWindow: true };
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab;
}

chrome.runtime.onInstalled.addListener(async () => {
    console.log('stigmark: loaded');
    setBadgeColor('#0c5');
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    console.log(`stigmark: ${changeInfo.status}`);
    if (changeInfo.status === 'complete') {
        console.log('stigmark: tab completed');
        const url = tab.url;
        const res = await is_stigmarked(url);
        if (res[url]) {
            setBadgetText('set');
        } else {
            setBadgetText('');
        }
    }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
    console.log('stigmark: tab activated');
    const tab = await getCurrentTab();
    const url = tab.url;
    const res = await is_stigmarked(url);
    if (res[url]) {
        setBadgetText('set');
    } else {
        setBadgetText('');
    }
});

chrome.action.onClicked.addListener(async (tab) => {
    console.log(`stigmark clicked: ${tab.url}`);
    const url = tab.url;
    const res = await is_stigmarked(url);
    if (res[url]) {
        stigunmark(url);
        setBadgetText('');
    } else {
        stigmark(url);
        setBadgetText('set');
    }
});
